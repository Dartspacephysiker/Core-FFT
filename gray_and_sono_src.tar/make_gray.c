/*
 * make_gray.c
 * $Header: /usr/local/radio/src/linux/gray/RCS/make_gray.c,v 1.4 2003/06/02 05:47:40 richard Exp $
 *
 * Module for gray program
 *
 * Responsible for writing a postscript file(s) representing
 * a data file according to the specifications of the definition information
 *
 * Modification history
 * 920916 Cacioppi - apparently debugged
 * 921230 Cacioppi - fixed bug - read_radio needs to return DTA_EOF when a good 
 *        read executed that reaches EOF, and ERROR when trying to read after 
 *        previous read reached EOF
 *        Updated so that can read ascii data files (calls read_ascii fctn)
 * 940424 RB Changed error exit codes to #defined constants.  Formatting cleanup
 * 970819 RB Fixed memory leak in write_bar() - avoid allocating memory to warr
 *        on each call.
 * 020618 RB Added pagelen and bars_per_page arguments to make_gray()
 * 020731 RB Begin modifications to accumulate the image and write it as a single postscript "image"
 *        instead of 1 image per vertical strip of grayscale.
 * 030601 RB Added Adobe Structured Document Comments to the output to make page previewers work better.
 *
 */

#include "gray.h"

char convert[] = "fedcba9876543210";        /* array to convert to hex  */

/*          prototypes for local functions          */
int     wrt_page (FILE *ps_file, FILE *data_file, def_info def, int rd_md, 
            int np, int log_scale, int pgs_wrtn, int pagelen, int bars_per_page);
void    begin_page (FILE *ps_file, def_info def, int pgs_wrtn);
void    end_page (FILE *ps_file);
int     write_header (FILE *ps_file);
void    lin_scale (dta_def dta, int *darr, int numpoints);
int     write_bar (FILE *ps_file, int *darr, int numpoints, int barnum, float x_width);
void    write_stamp (FILE *ps_file, char *str);

/* ---------------  functions providing interface   --------------------------- */
void make_gray (FILE *data_file, def_info def, int read_method, int paginate, int pipe, 
     int pagelen, int bars_per_page)    
{
    FILE *ps_file;
    char ps_name [STR_MAL]; 
    int numpoints, sts, fil_cnt=1, done, pgs_wrtn, log_scale;

    assert (data_file != NULL);
    assert ((read_method == RADIO_RD) || (read_method == ASCII_RD));

    numpoints = (int) def.y.dta_num;
    pgs_wrtn = 0;
    log_scale = def.dta.log_scl;

    /* use page counter to make file names, if paginating */
    if (paginate) sprintf (ps_name, "%s%03i", BASE_NAME, fil_cnt);
    
    else if (pipe)
        strcpy (ps_name,"-");
    else
        strcpy (ps_name, OUT_NAME);

    ps_file = good_open (ps_name, "w");

    if (!write_header (ps_file)){
        if (!pipe) remove (ps_name);
        exit (E_BADPSHEADER);
    }

    done = 0;
    while (!done){
        DBUG(fprintf(stderr,"good before wrt_page %d %d\n",fil_cnt, pgs_wrtn);)
        sts = wrt_page (ps_file, data_file, def, read_method, numpoints, 
                        log_scale, pgs_wrtn, pagelen, bars_per_page);
        DBUG(fprintf(stderr,"good after wrt_page\n");)
        switch (sts){
        case DTA_EOF:               /* if read all of data file         */
            done = 1;
            break;
        case ERROR:
            done = 1;
            break;
        default:
            pgs_wrtn++;
            if (paginate){
                fprintf (ps_file, "%%%%Trailer:\n%%%%EOF\n");
                fclose (ps_file);
                sprintf (ps_name, "%s%03i", BASE_NAME, ++fil_cnt);
                ps_file = good_open (ps_name, "w");
                if (!write_header (ps_file)){
                    if (!pipe) remove (ps_name);
                    exit (E_BADPSHEADER);
                }
            }
        }
    }


    fprintf (ps_file, "%%%%Trailer:\n%%%%EOF\n");
    fclose (ps_file);

    if (sts == ERROR) exit (E_BADWRTPAGE);

}

/* ---------------  functions providing implementation  ----------------------- */
/*
 * int wrt_page
 *
 * writes one page worth of data to a ps file, returning the status of it's efforts
 *
 */
int wrt_page (FILE *ps_file, FILE *data_file, def_info def, int rd_md, int np, 
            int log_scale, int pgs_wrtn, int pagelen, int bars_per_page)
{
    int *darr, *imgarr, barnum, sts=0;
    char title[STR_MAL], date[STR_MAL], s[STR_MAL];     
    stmp_dta stamp, *bfr;
    int running; 
    float x_width;

    assert ((ps_file != NULL) && (data_file != NULL));
    assert ((rd_md == RADIO_RD) || (rd_md == ASCII_RD));

    darr = malloc (np * sizeof(int));
    if (darr == NULL){
        fprintf (stderr, "ERROR in gray - insufficent memory. Could not find %i\n", 
                    np * sizeof(int));
        return ERROR;
    }   

    /* allocate a buffer for the whole page, not just a single stripe */
    imgarr = malloc (np * bars_per_page * sizeof(int));
    if (imgarr == NULL){
        fprintf (stderr, "ERROR in gray - insufficent memory. Could not find %i\n", 
                    np * bars_per_page * sizeof(int));
        return ERROR;
    }   

    bfr = (stmp_dta *) malloc (sizeof(stmp_dta));
    assert (bfr != NULL);
    
    x_width = ((float)pagelen/ (float)bars_per_page);

    strcpy (title, def.ttl.top_ttl);
    running = 1;
    for (barnum=0; ((barnum < bars_per_page) && running); barnum++){    
        if (rd_md == RADIO_RD){
            DBUG(fprintf(stderr,"good before read_radio\n");)
            sts = read_radio (data_file, np, darr, date, &stamp);
            if (sts != ERROR){                              /* if good read             */
                sprintf (s, "%s %s", date, title);          /* add date read to title   */
                strcpy (def.ttl.top_ttl, s);
                DBUG(fprintf(stderr,"good after read_radio - status %d\n",sts);)
            }
        }
        else if (rd_md == ASCII_RD){
            DBUG(fprintf(stderr,"good before read_ascii\n");)
            sts = read_ascii (data_file, np, def.x.stmp_mgc, def.x.mgc_char, darr, &stamp);
            DBUG(fprintf(stderr,"good after read_ascii - status %d\n", sts);)
        }
            
        /*stamp = *bfr; */
        switch (sts) {
        case ERROR:     /* if ERROR do not process data read and stop running   */
            running = 0;
            break;
        case DTA_EOF:   /* if end of data, process the data and stop running    */
            running = 0;
        default:
            if (barnum == 0)    /* if writing the first bar of data         */
                begin_page (ps_file, def, pgs_wrtn); /* first begin page    */  
            if (!log_scale)
                lin_scale (def.dta, darr, np);
            else{
                fprintf (stderr, "ERROR - log scale feature not implemented yet\n");
                exit (E_BADFEATURE);
            }
            write_bar (ps_file, darr, np, barnum, x_width); 
            /* if not using magic timestamps, then write a stamp after every SPEC_STMP bars */
            if (((!def.x.stmp_mgc) && ((barnum % SPEC_STMP) == 0)) ||   
                        ((def.x.stmp_mgc) && (stamp.mgc))) /* or use magic timestamps*/
                write_stamp (ps_file, stamp.str);
            fprintf (ps_file, "ETS ");          /* clean up PS stack    */
        }
    }


    end_page (ps_file);     /* finish writing one page of data  */
        
    free (bfr);
    free (darr);
    free (imgarr);
    return sts;
}


/*
 * begin_page
 *
 * writes the information neccessary to begin a page to a ps_file
 *
 */
void begin_page (FILE *ps_file, def_info def, int pgs_wrtn)
{

    float y_pos, y_val;
    int pageno;

    assert (ps_file != NULL);
    pageno = pgs_wrtn + def.ttl.pge_strt;

    fprintf (ps_file, "%%%%Page: %i %i\n", pageno, pageno);
    fprintf (ps_file, "NewPage\n");

    fprintf (ps_file, "(%s) StandardLabel\n", def.ttl.top_ttl);
    fprintf (ps_file, "(%s) SubLabel\n", def.ttl.sub_ttl);
    fprintf (ps_file, "(Page %i) RightTopLabel\n", pageno);

    if (def.dta.log_scl)
        fprintf (ps_file, "(Logarithmic ");
    else
        fprintf (ps_file, "(Linear ");
    fprintf (ps_file, "Scale     Black = %i     ", def.dta.blk_lvl);
    fprintf (ps_file, "White = %i) LeftTopLabel\n", def.dta.wht_lvl);

/*  NB the following are a patch for unimplemented feature - buffer zone        */
    if (def.y.lbl_max > def.y.dta_max) def.y.lbl_max = def.y.dta_max;
    if (def.y.lbl_min < def.y.dta_min) def.y.lbl_min = def.y.dta_min;

    for (y_val = def.y.lbl_min; y_val <= def.y.lbl_max; y_val += def.y.lbl_inc){
        y_pos = (y_val - def.y.dta_min) / (def.y.dta_max - def.y.dta_min);
        fprintf (ps_file, "(%3.1f)  %f LeftEdgeLabel\n", y_val, y_pos);
    }

    /* Old style - left axis label/bottom axis label both go in lower left corner */
    /* fprintf (ps_file, "(%s / %s) LeftBottomLabel\n", def.y.axs_lbl, def.x.axs_lbl); */
    /* New style - put botton axis label below the time labels */
    fprintf (ps_file, "(%s) LeftBottomLabel\n", def.y.axs_lbl);
    fprintf (ps_file, "(%s) BottomLabel\n", def.x.axs_lbl);
}

/*
 * int write_header
 *
 * Copy the header.ps file to a ps file
 * returns 1 if write successfull, 0 otherwise
 * The header with the postscript macros could be inlined here, or we could do some
 * limited editing as we go, treating the HPS_FILE* as templates rather than fixed text.
 *
 * We could add the %%Title: line as the input file name
 * We could add the %%Pages: line if we know already how many pages there are going to be
 *
 */
int write_header (FILE *ps_file)
{
    FILE *hps_file;         /* the header.ps file           */
    char bfr[STR_MAL];  

    hps_file = fopen (HPS_FILE1, "r");
    if (hps_file == NULL){
        hps_file = fopen (HPS_FILE2, "r");
        if (hps_file == NULL){
           fprintf (stderr, "ERROR - unable to find PostScript header file %s\n", HPS_FILE2);
           return 0;
        }
    }

    fgets (bfr, sizeof(bfr), hps_file);
    while (!feof(hps_file)){
        fputs (bfr, ps_file);
        fgets (bfr, sizeof(bfr), hps_file);
    }

    fclose (hps_file);
    return 1;
}

/*
 * end_page
 *
 */
void end_page (FILE *ps_file)
{
    assert (ps_file != NULL);
    fprintf (ps_file, "showpage\n");
}

/*
 * lin_scale
 *
 * scales a data array according to the black and white parameters
 *
 */

void lin_scale (dta_def dta, int *darr, int numpoints)
{
    int range, base, i, dmy;

    assert (darr != NULL);

    range = dta.blk_lvl - dta.wht_lvl;
    base = dta.wht_lvl;

    for (i=0; i<numpoints; i++){
        dmy = darr[i] - base;
        if (dmy < 0)
            dmy = 0;
        dmy = (dmy * NUM_CLRS) / range;
        if (dmy >= NUM_CLRS)
            dmy = NUM_CLRS - 1;
        assert ((dmy < NUM_CLRS) && (dmy >= 0));
        darr[i] = dmy;
    }
}

/*
 * void write_bar 
 *
 * writes a gray bar to a ps file
 *
 */
int write_bar (FILE *ps_file, int *darr, int numpoints, int barnum, float x_width)
{
    int i; 
    float x_pos;
    static char *warr = NULL;
    static int np = 0;

    assert (ps_file != NULL);
    assert (darr != NULL);


    if (np != numpoints) {
        /* number of points changed */
        if (warr) free(warr);
        if ((warr = malloc (numpoints + 1)) == NULL){
            fprintf (stderr, "ERROR - insufficent memory. Unable to find %i\n", numpoints);
            return 0;
        }
        np = numpoints;
    }

    for (i=0; i<numpoints; i++){
        assert ((darr[i] < NUM_CLRS) && (darr[i] >= 0));
        warr[i] = convert[ darr[i] ];
    }

    warr[numpoints] = '\0';

    x_pos = x_width * barnum;
    
    fprintf (ps_file, "%f %f BDS\n", x_pos, x_width);
    fprintf (ps_file, "%d 1 4 [%d 0 0 1 0 0]\n", numpoints, numpoints);
    fprintf (ps_file, "{<%s>} image EDS\n", warr);

    return 1;
}

/* 
 * write_stamp
 *
 * writes a timestamp to a ps file
 *
 */
void write_stamp (FILE *ps_file, char *str)
{
    assert (ps_file != NULL);
    assert (str != NULL);
    fprintf (ps_file, "(%s) TimeLabel\n", str);
}


