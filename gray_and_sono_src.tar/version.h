/*
 * version.h for gray program
 * 1.x 	- John Sahr version
 * 2.x	- Eric Olsen version
 * 3.x 	- Michael Quaye version
 * 4.0.x - Pete Caccioppi version
 * 4.1.x - Richard Brittain modifications (with contributions from 
 *         Al Weatherwax and Eric Lund)
 * 4.2.x - Richard Brittain, bugfixes, y2k problem
 * 4.3   - RB Linux port, bugfixes
 * 4.4   - RB Added options to customize "page size"
 * 4.5   - RB Modifications to write the page as a single postscript "image"
 *         instead of 1 image per vertical stripe
 */
#define VERSION "4.5"
