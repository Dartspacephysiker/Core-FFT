/*
 * read_def.c
 * $Header: /usr/local/radio/src/linux/gray/RCS/read_def.c,v 1.2 2003/06/02 03:01:45 richard Exp $
 *
 * module for gray program
 *
 * responsible for reading the definition information
 *
 * Modification history:
 * 9/11/92 Cacioppi debugged
 * 940424  RB Added #defines for exit() status codes (originally all error exits were
 *            status 1)
 *
 */

#include "gray.h"

#define LOOK_ONCE   1       /* flags for whether or not to look again in default file */    
#define LOOK_TWICE  2


/*      prototypes for local functions              */
def_info read_or_def (FILE *def_file, FILE *dflt_def);
def_info prmpt_or_def (FILE *dflt_def);
def_info good_def (FILE *def_file);
void    write_def (FILE *def_file, def_info def);
y_def   read_y_def (FILE *def_file, int info_sts, FILE *dflt_def);
void    write_y_def (FILE *def_file, y_def y);
x_def   read_x_def (FILE *def_file, int info_sts, FILE *dflt_def);
void write_x_def (FILE *def_file, x_def x);
ttl_def read_ttl_def    (FILE *def_file, int info_sts, FILE *dflt_def);
void    write_ttl_def (FILE *def_file, ttl_def ttl);
dta_def read_dta_def (FILE *def_file, int use_dlft, FILE *dflt_def);
void    write_dta_def (FILE *def_file, dta_def dta);
int     def_file_read(FILE *def_file, char *key, int info_sts, FILE *dflt_def, 
                    char dest[STR_MAL]);
int     read_key (FILE *def_file, char *key, char *dest);
char    *def_file_gets (char *s, int n, FILE *stream);
char    *rm_white (char *str);
char    *stolower (char *s, int n);


/* ---------------- functions providing interface ------------------------------ */
/*
 * def_info read_def
 *
 * reads the definition information
 *
 * passed   int   def_rd    - boolean- user provided a .def file?
 *          FILE  *user_def - the .def file provided by the user
 *          int   intrct    - boolean- read definition information by interacting with user
 *
 * returns  def_info        - the information read from the .def file
 *
 */
def_info read_def (int def_rd,  FILE *user_def, int intrct)
{
    FILE *dflt_def;         /* the default definition file      */
#ifdef INTERACTIVE
    FILE *wrt_def;          /* holds record of interactive def info */
#endif
    def_info rtn;   

    if (def_rd) assert (user_def != NULL);
    assert (!(def_rd && intrct));

    DBUG(fprintf(stderr, "read_def: %d, %d\n", def_rd, intrct);)


    /* try DFLT_DEF1 first (env var), if that fails, DFLT_DEF2 is mandatory */
    dflt_def = fopen (DFLT_DEF1, "r");
    if (dflt_def == (FILE *)NULL) {
        dflt_def = good_open (DFLT_DEF2, "r"); 
    }

    if (def_rd) {           /* if user provided .def file   */

        DBUG(fprintf(stderr,"Calling read_or_def: %p %p\n",user_def, dflt_def);)

        rtn = read_or_def (user_def, dflt_def);

        DBUG(fprintf(stderr,"Returned read_or_def: \n");)


    } else if (intrct){
        fprintf (stderr, "ERROR - interactive mode not implemented\n");
        exit(E_BADFEATURE);
#ifdef INTERACTIVE /* not yet implemented */
        /* the following lines of code will implemnet interactive mode for this function */
        wrt_def = good_open (WRT_DEF, "w");
        rtn = prmpt_or_def (dflt_def); !!!IMPLEMENT THIS FUNCTION!!!!
        write_def (wrt_def, rtn);
        fclose (wrt_def);
 
        /* write out the .def file generated from the interactive prompts, for future use */
        wrt_def = good_open ("test.def", "w");
        write_def (wrt_def, rtn);
        fclose (wrt_def);
#endif
    } else {
        rtn = good_def(dflt_def);
    }

    fclose (dflt_def);

    return rtn;

}

/* ------------------ functions providing implementation -------------------------*/
/*
 * def_info read_or_def
 *
 * reads definitio information from def_file, getting any values it cannot 
 * find there from deflt_def. Exits with bad status if unable to find a value from 
 * either file
 *
 */

def_info read_or_def (FILE *def_file, FILE *dflt_def)
{
    def_info rtn;

    DBUG(fprintf(stderr,"read_or_def:1\n");)
    assert ((def_file != NULL) && (dflt_def != NULL));
    DBUG(fprintf(stderr,"%p %p\n",def_file, dflt_def);)

    rtn.x = read_x_def (def_file, LOOK_TWICE, dflt_def);
    DBUG(fprintf(stderr,"read_or_def:2 %p %p\n",def_file, dflt_def);)
    rtn.y = read_y_def (def_file, LOOK_TWICE, dflt_def);
    DBUG(fprintf(stderr,"read_or_def:3\n");)
    rtn.ttl = read_ttl_def (def_file, LOOK_TWICE, dflt_def);
    DBUG(fprintf(stderr,"read_or_def:4\n");)
    rtn.dta = read_dta_def (def_file, LOOK_TWICE, dflt_def);
    DBUG(fprintf(stderr,"read_or_def:5\n");)
    
    return rtn;
}

/*
 * prompt_or_def
 *
 * prompts the user for definition information, getting default information from 
 * the default definition file.
 *
 */
def_info prmpt_or_def (FILE *dflt_def)
{

    fprintf (stderr, "ERROR - interactive mode not implemented\n");
    fprintf (stderr, "see function 'prompt_or_def' in module 'read_def.c'\n");
    exit(E_BADFEATURE);
    /*  9/4/92  Least used feature - leaving undone for later implementation    */

}

/*
 * good_def
 *
 * reads from a definition file. Exits with a bad status if definition file 
 * isn't complete
 *
 */
def_info good_def (FILE *def_file)
{
    def_info rtn;

    assert (def_file != NULL); 

    rtn.x = read_x_def (def_file, LOOK_ONCE, NULL);
    rtn.y = read_y_def (def_file, LOOK_ONCE, NULL);
    rtn.ttl = read_ttl_def (def_file, LOOK_ONCE, NULL);
    rtn.dta = read_dta_def (def_file, LOOK_ONCE, NULL);
    
    return rtn;
}

/*
 * write_def
 *
 * writes definition information to a definition file
 *
 */
void write_def (FILE *def_file, def_info def)
{
    assert (def_file != NULL);

    fprintf (def_file, "%c x axis information\n", CMNT_FLAG);
    write_x_def (def_file, def.x);

    fprintf (def_file, "\n%c y axis information\n", CMNT_FLAG);
    write_y_def (def_file, def.y);

    fprintf (def_file, "\n%c title information\n", CMNT_FLAG);
    write_ttl_def (def_file, def.ttl);

    fprintf (def_file, "\n%c data information\n", CMNT_FLAG);
    write_dta_def (def_file, def.dta);
}

/* -------------------------------------------------------------------------------- */
/* routines that contain key strings for looking up information in defintion files  */
/* -------------------------------------------------------------------------------- */
/* ------------- type conversions and bounds enforcing needs to be done ----------- */
/*
 * x_def read_x_def
 *
 * reads the definition information concerning the axis. 
 * If a certain piece of information cannot be found in def_file then...
 *  if info_sts has value LOOK_ONCE, function prints error message and exits with bad status
 *  else if info_sts has value LOOK_TWICE, function tries to find the information in dft_file
 *  if it cannot be found there, function prints error message and exits with a bad status
 *
 */
x_def read_x_def (FILE *def_file, int info_sts, FILE *dflt_def)
{
    x_def rtn;  
    char *ptr, stmp_mgc[STR_MAL], bfr[STR_MAL];

    assert (def_file != NULL); 
    if (info_sts == LOOK_TWICE) assert (dflt_def != NULL);
    assert ((info_sts == LOOK_ONCE) || (info_sts == LOOK_TWICE));   

    DBUG(fprintf(stderr,"read_x_def: 1\n");)

    def_file_read (def_file, "x_axis_label", info_sts, dflt_def, rtn.axs_lbl);

    DBUG(fprintf(stderr,"read_x_def: 2\n");)

    if ((ptr = strchr (rtn.axs_lbl, '\n')) != NULL)     /* replace newline  */
        *ptr = '\0';                            /* with string terminator   */ 

    def_file_read (def_file, "use_magic_stamps", info_sts, dflt_def, stmp_mgc);
    ptr = stolower (stmp_mgc, strlen(stmp_mgc));
    if (strncmp (ptr, "yes", 3) == 0)
        rtn.stmp_mgc = 1;
    else
        rtn.stmp_mgc = 0;

    def_file_read (def_file, "magic_char", info_sts, dflt_def, bfr);
    rtn.mgc_char = bfr[0];

    return rtn;
}

/*
 * write_x_def
 *
 * write the x_axis information to a definition file
 *
 */
void write_x_def (FILE *def_file, x_def x)
{
    char *stmp_mgc;

    fprintf (def_file, "x_axis_label %s\n", x.axs_lbl);

    if (x.stmp_mgc == 0)
        stmp_mgc = "no";
    else
        stmp_mgc = "yes";
    fprintf (def_file, "use_magic_stamps %s\n", stmp_mgc);

    fprintf (def_file, "magic_char %c\n", x.mgc_char);
}

/*
 * y_def read_y_def
 *
 * reads the definition information concerning the axis. 
 * If a certain piece of information cannot be found in def_file then...
 *  if info_sts has value LOOK_ONCE, function prints error message and exits with bad status
 *  else if info_sts has value LOOK_TWICE, function tries to find the information in dft_file
 *  if it cannot be found there, function prints error message and exits with a bad status
 *
 */
y_def read_y_def (FILE *def_file, int info_sts, FILE *dflt_def)
{
    char *ptr, bfr[STR_MAL];
    y_def rtn;
    assert (def_file != NULL); if (info_sts==LOOK_TWICE) assert (dflt_def != NULL);
    assert ((info_sts == LOOK_ONCE) || (info_sts == LOOK_TWICE));   
    
    def_file_read (def_file, "y_axis_label", info_sts, dflt_def, rtn.axs_lbl);
    if ((ptr = strchr (rtn.axs_lbl, '\n')) != NULL)     /* replace newline  */
        *ptr = '\0';                            /* with string terminator   */

    def_file_read (def_file, "y_label_min", info_sts, dflt_def, bfr);
    rtn.lbl_min =atof(bfr);
    def_file_read (def_file, "y_label_max", info_sts, dflt_def, bfr);
    rtn.lbl_max =atof(bfr);
    def_file_read (def_file, "y_label_increment", info_sts, dflt_def, bfr);
    rtn.lbl_inc =atof(bfr);
    def_file_read (def_file, "y_data_min", info_sts, dflt_def, bfr);
    rtn.dta_min =atof(bfr);
    def_file_read (def_file, "y_data_max", info_sts, dflt_def, bfr);
    rtn.dta_max =atof(bfr);
    def_file_read (def_file, "y_data_num", info_sts, dflt_def, bfr);
    rtn.dta_num =atof(bfr);

    return rtn;
}

/*
 * write_y_def
 *
 * writes the y axis information to a definition file 
 *
 */
void write_y_def (FILE *def_file, y_def y)
{
    assert (def_file != NULL);

    fprintf (def_file, "y_axis_label %s\n", y.axs_lbl);
    fprintf (def_file, "y_label_min %f\n", y.lbl_min);
    fprintf (def_file, "y_label_max %f\n", y.lbl_max);
    fprintf (def_file, "y_label_inc %f\n", y.lbl_inc);
    fprintf (def_file, "y_data_min %f\n", y.dta_min);
    fprintf (def_file, "y_data_max %f\n", y.dta_max);
    fprintf (def_file, "y_data_num %f\n", y.dta_num);

}


/*
 * dta_def read_dta_def
 *
 * reads the definition information concerning the axis. 
 * If a certain piece of information cannot be found in def_file then...
 *  if info_sts has value LOOK_ONCE, function prints error message and exits with bad status
 *  else if info_sts has value LOOK_TWICE, function tries to find the information in dft_file
 *  if it cannot be found there, function prints error message and exits with a bad status
 *
 */
dta_def read_dta_def (FILE *def_file, int info_sts, FILE *dflt_def)
{
    dta_def rtn;
    char *log_scl, bfr[STR_MAL];
    assert (def_file != NULL); if (info_sts==LOOK_TWICE) assert (dflt_def != NULL);
    assert ((info_sts == LOOK_ONCE) || (info_sts == LOOK_TWICE));   
    
    def_file_read (def_file, "data_white_level", info_sts, dflt_def, bfr);
    rtn.wht_lvl = (int) atof(bfr);
    def_file_read (def_file, "data_black_level", info_sts, dflt_def, bfr);
    rtn.blk_lvl = (int) atof(bfr);

    def_file_read (def_file, "gray_log_scale", info_sts, dflt_def, bfr);
    log_scl = stolower (bfr, strlen(bfr));
    if (strncmp (log_scl, "yes", 3) == 0)
        rtn.log_scl = 1;
    else
        rtn.log_scl = 0;

    return rtn;

}

/*
 * write_dta_def
 *
 * writes out to a definition file the data information 
 *
 */
void write_dta_def (FILE *def_file, dta_def dta)
{
    char *log_scl;
    assert (def_file != NULL);

    fprintf (def_file, "data_white_level %i\n", dta.wht_lvl);
    fprintf (def_file, "data_black_level %i\n", dta.blk_lvl);

    if (dta.log_scl == 0)
        log_scl = "no";
    else
        log_scl = "yes";

    fprintf (def_file, "gray_log_scale %s\n", log_scl);
}

/*
 * ttl_def read_ttl_def
 *
 * reads the definition information concerning the axis. 
 * If a certain piece of information cannot be found in def_file then...
 *  if info_sts has value LOOK_ONCE, function prints error message and exits with bad status
 *  else if info_sts has value LOOK_TWICE, function tries to find the information in dft_file
 *  if it cannot be found there, function prints error message and exits with a bad status
 *
 */
ttl_def read_ttl_def (FILE *def_file, int info_sts, FILE *dflt_def)
{
    ttl_def rtn;
    char *ptr, bfr[STR_MAL];

    assert (def_file != NULL); if (info_sts==LOOK_TWICE) assert (dflt_def != NULL);
    assert ((info_sts == LOOK_ONCE) || (info_sts == LOOK_TWICE));   

    def_file_read (def_file, "title", info_sts, dflt_def, rtn.top_ttl);
    if ((ptr = strchr (rtn.top_ttl, '\n')) != NULL)     /* replace newline  */
        *ptr = '\0';                            /* with string terminator   */

    def_file_read (def_file, "sub_title", info_sts, dflt_def, rtn.sub_ttl);
    if ((ptr = strchr (rtn.sub_ttl, '\n')) != NULL)     /* replace newline  */
        *ptr = '\0';                            /* with string terminator   */

    def_file_read (def_file, "page_start", info_sts, dflt_def, bfr);
    rtn.pge_strt =  atoi(bfr);
    
    return rtn;

}
/*
 * write_ttl_def
 *
 * writes out to a definition file the title information 
 *
 */
void write_ttl_def (FILE *def_file, ttl_def ttl)
{
    assert (def_file != NULL);

    fprintf (def_file, "title %s\n", ttl.top_ttl);
    fprintf (def_file, "sub_title %s\n", ttl.sub_ttl);
    fprintf (def_file, "page_start %i\n", ttl.pge_strt);
    
}

/* -------------------------------------------------------------------- */
/* end of routines with key strings for looking up in defintion files   */
/* -------------------------------------------------------------------- */

/*
 * int def_file_read 
 * 
 * returns the standardized string identified by key from a definition file 
 *
 * If key cannot be found in def_file then...
 *  if info_sts has value LOOK_ONCE, function prints error message and exits with bad status
 *  else if info_sts has value LOOK_TWICE, function tries to find the information in dft_file
 *  if it cannot be found there, function prints error message and exits with a bad status
 * 
 */
int def_file_read(FILE *def_file, char *key, int info_sts, FILE *dflt_def, char dest[STR_MAL])
{
    char rtn[STR_MAL];
    int errflg = 0;
    assert (def_file != NULL); if (info_sts==LOOK_TWICE) assert (dflt_def != NULL);
    assert ((info_sts == LOOK_ONCE) || (info_sts == LOOK_TWICE));   


    DBUG(fprintf(stderr,"def_file_read: 1 key=%s\n",key);)

    if (read_key (def_file, key, rtn) == 0){    /* if def_file doesn't have key     */
        DBUG(fprintf(stderr,"def_file_read: 2 rtn=%s\n",rtn);)
        if (info_sts == LOOK_ONCE)              /* if supposed to look once         */
            errflg++;                           /* then bad read                    */
        else if (info_sts == LOOK_TWICE){       /* else if supposed to read twice   */
            if (read_key (dflt_def, key, rtn) == 0){    /* see if dflt_def has key  */
                errflg++;                       /* if it doesn't, then bad read     */
            }
        }
    }

    if (errflg){
        fprintf (stderr, "ERROR - unable to read %s\n", key); /* if unable to find key  */  
        exit (E_BADKEY);                /* print error message and exit with bad status */
    }

    strcpy (dest, rtn);
    DBUG(fprintf(stderr,"def_file_read: 3 dest=%s\n",dest);)
    return 1;
}

/*
 * int read_key
 *
 * copies the standardized string following key in def_file into dest
 * retuns 0 is not found, 1 otherwise 
 *
 */
int read_key (FILE *def_file, char *key, char *dest)
{
    char *bfr, *p, *rtn=NULL;
    int r;
    int offset;
    int done = 0;
    assert (def_file != NULL);
    assert (key != NULL);
    assert (dest != NULL);

    DBUG(fprintf(stderr,"read_key:1 key=%s\n",key);)

    if ((bfr = (char *)malloc (STR_MAL)) == NULL){
        fprintf (stderr, "ERROR, insufficent memory. Unable to find %i\n", STR_MAL);
        exit (E_NOMEM);
    }

    DBUG(fprintf(stderr,"read_key:1a initial bfr=%s %p\n",bfr,bfr);)

    fseek (def_file, 0L, SEEK_SET);
    while (!done){
        p = def_file_gets (bfr, STR_MAL, def_file);

        DBUG(fprintf(stderr,"read_key:2 after def_file bfr=%s %p\n",bfr,bfr);)

        offset = strcspn (p, " \t\0\n");        /* get length of first word */
        if ((offset == strlen(key)) &&          /* if first word right size */
            (strncmp (p, key, offset) == 0)){   /* and matches key          */
            rtn = rm_white (p + offset);        /* skip past first word     */ 

            DBUG(fprintf(stderr,"read_key:3 found %s %p\n",rtn,rtn);)

            done++;
        }
        else if (feof(def_file)){
            done++;
            free (bfr); 
            rtn = NULL;
        }
    }

    if (rtn != NULL){
        strcpy (dest, rtn);
        DBUG(fprintf(stderr,"read_key:4 - returning %s %p bfr=%p\n",dest,dest,bfr);)
        free (bfr);
        DBUG(fprintf(stderr,"read_key:5 - returning %s %p\n",dest,dest);)
        r = 1;
    } else {
        r = 0;
        DBUG(fprintf(stderr,"read_key:6 - returning %s %p\n",dest,dest);)
    }
    
    
    return r;
}

/*
 * char *def_file_gets
 *
 * returns a line from the definition file. The comments are removed from the line, 
 * as are leading and trailing white spaces. The first word is converted to lower case,
 * so that 'keywords' are always compared in lower case.
 *
 * s is scratch space to hold the line.  The return value is a char * pointing to the start
 * of the first word.  It is NOT necessarily pointing to the start of s.
 *
 */
char *def_file_gets (char *s, int n, FILE *def_file)
{
    char *bfr;
    char *rtn;
    int l;

    DBUG(fprintf(stderr, "def_file_gets\n");)

    fgets (s, n, def_file);

    /*  terminate the string at the first incidence of the comment flag     */
    if ((bfr = (char *)strchr (s, (char)CMNT_FLAG)) != NULL)    /* if CMNT_FLAG found*/
        *bfr = '\0';                    /* replace with string terminator*/
    
    rtn = rm_white (s);                 /* remove leading white spaces from s*/
    l = strcspn (rtn, " \t\0\n");       /* get length of first word */
    rtn = stolower (rtn, l);            /* convert first word to lower case */
    return rtn;                         /* return a pointer to the start of the first word */
}

/*
 * rm_white
 *
 * passed a non null string (char *)
 *
 * returns a char * to the original string with the leading  
 * and trailing white spaces removed
 *
 */
char *rm_white (char *str)
{
    int i, done;
    char *rtn, *last;
    
    assert (str != NULL);
    
    DBUG(fprintf(stderr,"rm_white: %s\n",str);)

    done = 0;
    i=0;
    while (!done){          /* first skip past leading tabs and newlines    */
        done = ((str[i] != ' ') && (str[i] != '\t')); 
        if (!done)
            i++;
    }   

    rtn= str + i;

    last = rtn;
    done = 0;
    i=0;
    while (!done){
        if ((rtn[++i] == '\n') || (rtn[i] == '\0'))
            done = 1;
        else if ((rtn[i] != ' ') && (rtn[i] != '\t'))   
            last = rtn + i;
    }
    last[1] = '\0';

    return rtn;
}

/*
 * char *stolower
 *
 * converts the letters in the first n characters of s to lower case
 *
 */
char *stolower (char *s, int n)
{
    int i;
    int l = strlen (s);

    /* insure that we're not trying to write past the end of the string */
    if (n > l)
        n = l;

    for (i=0; i<n; i++)
        if (isupper((int) s[i]))                /* if it's an upper case char   */
            s[i] = (char) tolower((int) s[i]);  /* convert it to lower case     */ 
        
    return s;
}
