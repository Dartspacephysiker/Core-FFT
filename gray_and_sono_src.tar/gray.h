/*
 * gray.h
 * $Header: /usr/local/radio/src/linux/gray/RCS/gray.h,v 1.2 2003/06/02 02:55:23 richard Exp $
 *
 * header file for gray program
 *
 * contains -   prototypes for all global functions 
 *          -   typedefs for all types that can be passed between modules
 *          -   all #includes that are required by more than one module
 *          -   all #defines that are required by more than 1 module
 *          -   the following specific information placed here for easy access
 *              a)  the name of the required gray.def file that provides default values
 *              b)  the name of the reuired header.ps file 
 *              c)  the names used for creating .ps files
 *
 */

/*      #includes used by every module              */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <ctype.h>

/*      file names placed here for easy access      */
#define HPS_FILE1   getenv("GRAY_PSHD")
#define HPS_FILE2   "/usr/local/radio/lib/gray_header.ps"

#define DFLT_DEF1   getenv("GRAY_DEF")
#define DFLT_DEF2   "/usr/local/radio/lib/gray_defaults.def"

#define WRT_DEF     "gray.def"      /* if interactive mode, this .def file is written*/

#define OUT_NAME    "gray.ps"       /* if not paginating, name of output file       */
#define BASE_NAME   "gray."         /* if paginating, append outfile num to this    */

/*      Exit codes - used for fatal errors */
#define E_NOERR         0       /* completed with no error */
#define E_NOARGS        1       /* called with no options or arguments */
#define E_BADREAD       2       /* cannot open file for reading */
#define E_BADWRITE      3       /* cannot open file for writing */
#define E_BADFEATURE    4       /* attempted to use an unimplemented feature */
#define E_BADKEY        5       /* failed to locate required keyword in header file */
#define E_NOMEM         6       /* memory allocation failed */
#define E_BADPSHEADER   7       /* failure preparing postscript header */
#define E_BADWRTPAGE    8       /* failure while writing postscript page */

/*      Debugging assistance */
#ifdef DEBUG
#define exit(status)    fprintf(stderr,"Exit in %s, line %d, exitstatus %d\n",\
                        __FILE__, __LINE__, status),\
                        exit(status) ;
#define DBUG(x) x
#else
#define DBUG(x)
#endif

/*      read only globals   */
#define ASCII_RD    0           /* flag for reading from an ASCII data file */
#define RADIO_RD    1           /* flag for reading from a radio data file  */
#define STR_MAL     80          /* a good size for a string     */
#define DTA_EOF     -1          /* flag or end of a data file   */
#define ERROR       0           /* error flag                   */
#define GOOD        1           /* all's well                   */  

/*      used in the grayscale generation routines */
#define NUM_CLRS    16          /* the number of shades of gray that can be printed out */
#define BARS_PG     420         /* the number of gray bars per page */
#define PG_LNGTH    680         /* the printable length of the x coordinate axis, in points */ 
#define SPEC_STMP   27          /* if not magic stamps, print this many timestamps per page */

#define CMNT_FLAG   '#'         /* flag for comments in the definition and ASCII data files */

/* This really has no business being here - should default from header config file instead */
#define DEF_YEAR    1970        /* for reading from radio files, the default year */

/*      types used for information read from the .def files     */
typedef struct x_info{          /* holds info concerning x axis */
    char axs_lbl[STR_MAL];      /* the label of the x axis      */
    int stmp_mgc;               /* boolean- write only magic timestamps?*/
    char mgc_char;              /* char which starts magic timestamps   */
} x_def;

typedef struct y_info{          /* holds info concerning y axis     */
    char axs_lbl[STR_MAL];      /* the label of the y axis          */
    float lbl_min;              /* the bottom of the y axis         */
    float lbl_max;              /* the top of the y axis            */
    float lbl_inc;              /* incement between y axis labels   */
    float dta_min;              /* minimum value of the y data      */
    float dta_max;              /* maximum value of the y data      */
    float dta_num;              /* number of y data points in a stripe  */
} y_def;

typedef struct data_info {      /* info regarding presentation of data  */
    int wht_lvl;                /* white level, all points <= are white */
    int blk_lvl;                /* black level, all points >= are black */
    int log_scl;                /* boolean- use a logarithmic scale?    */
} dta_def;

typedef struct title_info {     /* info concerning title of each page   */
    char top_ttl[STR_MAL];      /* the title of the page                */
    char sub_ttl[STR_MAL];      /* the sub title of the page            */
    int pge_strt;               /* page number of first page            */
} ttl_def;      

typedef struct def_struct {     /* hold entire definition information   */
    x_def x;                    /* information concerning the x axis    */
    y_def y;                    /* information concerning the y axis    */
    dta_def dta;                /* info regarding presentation of data  */
    ttl_def ttl;                /* info concerning title of each page   */
} def_info;

/*  types for information read from the data files                      */
typedef struct time_struct {    /* sturct holds timestamp info          */
    char str[STR_MAL];          /* the timestamp read                   */
    int mgc;                    /* boolean: is timestamp magic?         */
} stmp_dta;

/*      prototype for global functions                                  */
def_info read_def (int def_rd,  FILE *user_def, int intrct);
void make_gray (FILE *data_file, def_info def, int read_method, int paginate, int pipe, int pagelen, int bars_per_page);
int read_radio (FILE *datafile, int numpoints, int *darr, char *date, stmp_dta *stamp);
int read_ascii (FILE *datafile, int numpoints, int magic, char mgc_char, int *darr, stmp_dta *stamp);
FILE *good_open (char *name, char *status);


