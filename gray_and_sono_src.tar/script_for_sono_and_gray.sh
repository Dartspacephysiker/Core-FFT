#!/bin/sh
# for datafile in transp_test_overnight_master_*.data; do
for datafile in master*; do
   echo "Processing $datafile..."
   od -v -t u1 -w2 -A n $datafile | ./sono_complex_long
   mv graydata $datafile.graydata
   gray -d ngray.def $datafile.graydata
   ps2pdf gray.ps
   mv gray.pdf $datafile.pdf
   rm gray.ps
   #rm graydata
   #rm ngray.def
   # get the base part of the filename, strip off all directories
   # datafile=`basename $datafile`
 done

