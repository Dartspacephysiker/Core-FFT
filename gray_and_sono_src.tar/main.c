/*
 * main.c
 * $Id: main.c,v 1.3 2003/06/02 03:26:10 richard Exp $
 *
 * module for processing command_line for gray program
 * also contains general utility functions
 *
 * Modification history:
 * 950424 RB Added #defined exit code (E_...) for all possible exit points.
 * 020619 RB Added variables for page length and bars/page (pagelen, bars_per_page).
 *
 */

#include "gray.h"
#include "version.h"

typedef struct options_struct { /* struct for holding command line options      */
    int def_rd;                 /* boolean - user provides def file?            */
    char *def_name;             /* if so - name of def file provided            */
    int intrct;                 /* boolean - user wishes for interactive mode   */
    int read_method;            /* what method to use for reading the data      */
    int dta_rd;                 /* boolean - user specify data file to be read? */
    char *data_name;            /* if so - name of data file specified by user  */
    int pipe;                   /* boolean - read data from stdin?              */
    int paginate;               /* boolean - each page has own ps file?         */
    int verbosity;              /* required level of chattiness                 */
    int pagelen;                /* page length, in points, printable data area  */
    int bars_per_page;          /* data sweeps (bars) per printed page          */
} opt_info;

opt_info no_options = {0, NULL, 0, ASCII_RD, 0, NULL, 0, 0, 0, PG_LNGTH, BARS_PG};

/*      prototypes for local functions                  */
opt_info command_line (int argc, char *argv[]);

int main (int argc, char *argv[])
{
    def_info def;
    opt_info options;
    FILE *data_file, *user_def;

    options = command_line (argc, argv);        /* read the command line    */

    if (options.def_rd)                         /* if user gave a def file  */
        user_def = good_open (options.def_name, "r");   /* open it          */
    else
        user_def = NULL;                        /* else no user def file    */

    DBUG(fprintf(stderr,"good before reading options\n");)
    def = read_def (options.def_rd, user_def, options.intrct);  /*read definition info  */
    DBUG(fprintf(stderr,"good after reading options\n");)

    if (options.def_rd){
        assert (user_def != NULL);
        fclose (user_def);
    }

    if (options.dta_rd)                         /* if user supplied data file   */  
        data_file = good_open (options.data_name, "r"); /* open the data file   */
    else if (options.pipe)
        data_file = stdin;          /* else if user wants to read from a pipe   */
    else
        assert (0);                 /* command line should check this           */

/*  make a ps file from the data file, according to the specifications of the definition info   */      
    DBUG(fprintf(stderr,"good before make_gray\n");)
    make_gray (data_file, def, options.read_method, options.paginate, options.pipe, options.pagelen, options.bars_per_page );
    DBUG(fprintf(stderr,"good after make gray\n");)
    if (!options.pipe)
        fclose (data_file); 

    return (E_NOERR);
}

/*
 * opt_info command_line
 *
 * reads the command_line information
 *
 */
opt_info command_line (int argc, char *argv[])
{
    opt_info rtn;
    int c, errflg;
    extern int optind, opterr;
    extern char *optarg;

    rtn = no_options;           /* default to no options, have user overwrite   */

    errflg = 0;

    while ((c = getopt (argc, argv, "ipPrvd:l:b:")) != EOF)
        switch (c){
        case 'i':
            rtn.intrct = 1;
            break;
        case 'p':
            rtn.pipe = 1;
            break;
        case 'P':
            rtn.paginate = 1;
            break;
        case 'r':
            rtn.read_method = RADIO_RD;
            break;
        case 'v':
            rtn.verbosity = 1;
            break;
        case 'd':
            if (optarg == NULL)
                errflg++;
            else{
                rtn.def_rd = 1;
                rtn.def_name = optarg;
            }
            break;
        case 'l':
            if (optarg == NULL)
                errflg++;
            else
                rtn.pagelen = atoi(optarg);
            break;
        case 'b':
            if (optarg == NULL)
                errflg++;
            else 
                rtn.bars_per_page = atoi(optarg);
            break;
        case '?':
            errflg++;
        }

    if ((rtn.read_method == RADIO_RD) && (rtn.pipe)){
        fprintf (stderr, "ERROR - unable to read a radio file from a pipe\n");
        errflg++;
    }
    if ((rtn.def_rd) && (rtn.intrct)){
        fprintf (stderr, "ERROR - interactive mode not compatible with reading a defintion file\n");
        errflg++;
    }
    if ((rtn.intrct) && (rtn.pipe)){
        fprintf (stderr, "ERROR - unable to read from a pipe in interactive mode\n");
        errflg++;
    }

    if ((rtn.pipe) && (optind != argc)) /* if reading from a pipe, no arguments should remain   */
        errflg++; 
    if ((!rtn.pipe) && (optind != (argc - 1)))  /* if not pipe, make sure passed file to process*/
        errflg++;

    if (rtn.verbosity > 0) fprintf(stderr, "Gray: version %s of %s \n", VERSION, __DATE__);

    if (errflg){
        fprintf (stderr, "usage    : gray [-d def_file | -i] [-p] [-P] [-r] [-v] [-l pagelen] [-b bars_per_page] <data_file>\n");
        fprintf (stderr, "def_file : definition file provided by user\n");
        fprintf (stderr, "-i       : interactive mode - read definition info from user\n");
        fprintf (stderr, "-p       : pipe - read data from stdin \n");
        fprintf (stderr, "-P       : paginate - each page has own postscript file\n");
        fprintf (stderr, "-r       : radio file option - read data from a radio file\n");
        fprintf (stderr, "-v       : turn on informational messages\n");
        fprintf (stderr, "-l       : specify page length, in points\n");
        fprintf (stderr, "-b       : specify bars per page\n");
        fprintf (stderr, "data_file: data file to be read - ignored if -p\n");
        exit (E_NOARGS);
    }
    
    if (rtn.pipe)
        return rtn;

    assert (optind == (argc - 1));
    rtn.dta_rd = 1;
    rtn.data_name = argv[optind];


        DBUG(fprintf(stderr,"%s %s\n",rtn.def_name, rtn.data_name);)

    return rtn;
}
/* ------------------------- general utility functions --------------------------*/
/*
 * FILE *good_open
 *
 * returns the FILE * speciied by it's arguments, or exits with a bad status
 *
 * passed   char *name  -   the name of the file to open, or "-" for stdin,stdout
 *
 *          char *status-   -r for reading (or stdin), -w for writing (or stdout)
 *
 */

FILE *good_open (char *name, char *status)
{
    FILE *rtn;
    int  estatus=E_NOERR;


    DBUG(fprintf(stderr,"good_open:1 %s %s\n", name, status);)

    assert ((name != NULL) && (status != NULL));
    assert ((status[0] == 'w') || (status[0] == 'r'));

    if (strcmp(name,"-")==0 ){
        if (strchr(status,'w') != NULL)
            rtn = stdout;
        else
            rtn = stdin;
    }
    else {
        if ((rtn = fopen (name, status)) == NULL){
            fprintf (stderr, "ERROR unable to open %s ", name);
            if (status[0] == 'r') {
                fprintf (stderr, "for reading ");
                estatus = E_BADREAD;
            } else if (status[0] == 'w') {
                fprintf (stderr, "for writing ");
                estatus = E_BADWRITE;
            }
            fprintf (stderr, "\n");
            exit (estatus);
        }
    }

    return rtn;
}

