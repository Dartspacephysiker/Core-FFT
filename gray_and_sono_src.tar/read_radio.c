/*
 * read_radio.c
 * $Header: /usr/local/radio/src/linux/gray/RCS/read_radio.c,v 1.4 2008/05/12 05:49:14 richardb Exp $
 *
 * module for gray program
 *
 * responsible for reading data from a raw radio file 
 *
 * Modification History 
 *  10/21/92 Cacioppi modified to improve time stamp autoscaling
 *  12/21/92 Cacioppi modified to use first few timestamps for autoscaling
 *           information, and insure that at least one timestamp is
 *           printed with very short files
 *  950130  RB  fixed bug with timestamp handling on a year wrap.  Timestamps from spr
 *          increment monotonically past a year-end, but the routines to convert to
 *          time and date strings must be given a value in range.
 *  950424  RB  miscellaneous cleanup in comments and structure and message spelling.
 *          With the v4.10/v4.11 timestamp error, checking with STMP_CHK=20 triggers 
 *          an apparent backward jump when setting the auto scaled time axis, and gray
 *          gray dies.  Set to some other value to avoid this
 *  000317  RB v4.2.1  y2k fix - make year full 4 digits.
 #  080512  RB Rename round() to roundud() to avoid library conflict
 *
 */

#include "gray.h"
#include "radio.h"

/*      read only globals   */
#define SPEC_INT    28          /* a good spectrum interval between magic timestamps*/
#define STMP_CHK    30 /*20*/   /* num timestamps to read to find average interval */
#define UP          1           /* flags for whether to round up or down */
#define DOWN        2
#ifndef DEBUG
#define DEBUG       0           /* flag for providing debugging information */
#endif

int min_intvals[7] = {1, 2, 5, 10, 15, 20, 30}; /* the possible minute intervals for */
                                                /* intervals less then one hour     */
int hour_intvals[6] = {1, 2, 4, 6, 12, 24};     /* the possible hour intervals for  */
                                                /* intervals greater then one hour  */

typedef struct header_information {         /* struct holding the header information */
    int numfreq;                            /* the number of frequencies */
    int bytespec;                           /* the number of bytes per spectra */
    int bytesfreq;                          /* the number of bytes per frequency */
    int numspec;                            /* the number of spectra */
    int year;                               /* the year as read from the header */  
    long topdata;                           /* beginning of the data/end of header */
} hd_strct; 

typedef struct scaling_information {        /* struct to hold the scaling information */
    t_stamp first;                          /* first timestamp to print */
    long interval;                          /* interval between printed timestamps  */
} scl_strct;

static t_stamp max_stamp;                   /* maximum timestamp in a year (depends on leapyear) */

/*      prototype for local functions       */
int     rd_header (FILE *datafile, hd_strct *header);
int     check_header (FILE *datafile, hd_strct *header, int numpoints);
int     check_long (long chk, char *key);
int     get_numspec (FILE *datafile, int bytespec, int topdata);
t_stamp read_last (FILE *datafile, hd_strct header);
int     read_scale (FILE *datafile, hd_strct header, scl_strct *scale);
long    read_timespan (FILE *datafile, hd_strct header, int i);
long    rd_intval (int intvals[], int sz, long convert, long rough);
long    compare (long one, long two, long base);
long    roundud (long arg, long base, int where);
static  int check_leapyear(int year);

/* ------------------------ functions providing interface --------------------  */
/* 
 * int read_radio
 *
 * reads a spectrum  from a raw radio file
 *
 * passed   FILE    *datafile - the radio file to read from. CANNOT be a pipe.
 *          int     numpoints - the number of frequencies to return
 *          int     *darr     - the array of data points to be filled 
 *          char    *date     - to be filled with a string translation of *stamp
 *          stmp_dta *stamp   - timestamp data to be filled
 
 * returns  int               - GOOD if a good read was executed that did not reach EOF
 *                            - DTA_EOF if good read was executed that reached EOF
 *                            - ERROR if a bad read was executed
 *
 * exceptions                 - datafile must be a raw radio file with a complete header
 *                            - darr should be large enough to hold numpoints ints  
 *                            - behavior is undefined on a machine for which ints and 
 *                              longs are not equivalent
 *
 */
int read_radio (FILE *datafile, int numpoints, int *darr, char *date, stmp_dta *stamp)
{
    static int specread=0;          /* counter for number of spectra read   */
    static int yearwrapped=0;       /* have we wrapped round a year end  */
    static scl_strct scale;         /* holds the scaling information */
    static hd_strct header;         /* holds the information read from the header   */
    static t_stamp prev;            /* the previous time stamp  */
    static t_stamp nxt_mgc;         /* the next magic timestamp to be printed   */
    long pos, last=0;                       
    t_stamp next;
    stmp_dta s;
    char str[STR_MAL];
    unsigned long bfr;
    int i;

    assert (datafile != NULL);
    assert (darr != NULL);
    assert (date != NULL);
    assert (stamp != NULL);

    if (specread == 0){             /* if first time call */
        if (!rd_header (datafile, &header)) {
            if (DEBUG) printf("Error reading radio file header\n");
            return ERROR;
        }
        if (!check_header (datafile, &header, numpoints)) {
            if (DEBUG) printf("Error checking radio file header\n");
            return ERROR;
        }
        /* maximum timestamp in the current year - v4.2.1 assume full 4 digit year now */
        /* max_stamp = check_leapyear(header.year+1900) ? MAX_STAMP : MAX_STAMP-(SEC_DAY*10); */
        max_stamp = check_leapyear(header.year) ? MAX_STAMP : MAX_STAMP-(SEC_DAY*10);
        if (!read_scale (datafile, header, &scale)) {
            if (DEBUG) printf("Error setting time scale\n");
            return ERROR;
        }
        nxt_mgc = scale.first;
        last = read_last(datafile, header);
    }
    if (specread >= header.numspec) {
        if (DEBUG) printf("Error in radio file\n");
        return ERROR; 
    }

    /* skip over auxiliary channels and leave us positioned for the next timestamp */
    pos = header.topdata + (header.bytespec * specread);
    fseek(datafile, pos, SEEK_SET);

    /*  first deal with the timestamp */
    next = rd_timestamp (datafile);                 /* read the next timestamp */

    if (DEBUG) printf("%lu %lu %lu %d\n", next, nxt_mgc, max_stamp, header.year);

    if (next >= nxt_mgc) {                          /* time to print a timestamp */
        if (!yearwrapped && (next > max_stamp)) {
            /* deal with year wrap - but only do it once.  A file can never cross two year wraps */
            header.year++;
            yearwrapped = 1;
            if (DEBUG) printf("wrapped around end of year - nxt_mgc=%lu\n",nxt_mgc);
        }
        if (rd_time (nxt_mgc%max_stamp, str) != 1)  /* make sure get a good read of the time */
            return ERROR; 
        if (rd_date (nxt_mgc%max_stamp, header.year, date) != 1)/* insure a good read of the date*/
            return ERROR; 
        s.mgc = 1;                                  /* flag our magic timestamp */
        nxt_mgc = (nxt_mgc + scale.interval);       /* set the next magic timestamp */
    } else { 
        if (rd_time (next%max_stamp, str) != 1)     /* make sure get a good read of the time*/
            return ERROR; 
        if (rd_date (next%max_stamp, header.year, date) != 1)   /* insure a good read of the date */
            return ERROR; 
        if ((specread == 0) &&              /* if reading first timestamp */
             (last <= scale.first))         /* and no timestamp is going to be printed */
            s.mgc = 1;                      /* make sure that the first timestamp is printed */
        else 
            s.mgc = 0;                      /* otherwise, ordinary timestamp */
    }
    /* copy the timestamp string, as returned by rd_time (hh:mm:ss) */
    strcpy (s.str, str);
    /* now truncate the seconds since they are always 00 */
    s.str[strlen(s.str)-3] = '\0';    

    (*stamp) = s;
    prev = next;
    specread++;
        
    /*  now copy over the data */
    for (i=0; i<numpoints; i++){
        assert (!feof(datafile));
        rd_freq (datafile, &bfr, header.bytesfreq);
        darr[i] = (int) bfr;
    }


    if (specread == header.numspec)         /* if read last spectra of the file..   */
        return DTA_EOF;                     /* then indicate the end of the data    */
    if (specread < header.numspec)          /* if more spectra left to be read..    */
        return GOOD;                        /* then a normal read was performed     */
    assert (1 == 0);                        /* this should never be reacched        */      

}

/* ---------------------functions providing implementation  ----------------------- */

/*
 * int rd_header
 *
 * reads informtation from the header placing it in hd_strct *header 
 *
 * returns 0 on a bad read, 1 on a good read
 * 
 */
int rd_header (FILE *datafile, hd_strct *header)
{
    hd_strct hdr;
    rl_hd *h;

    assert (datafile != NULL);
    assert (header != NULL);

    if (DEBUG) printf ("good entering read_header\n");

/* even though this module not pipe-clean, using pipe_clean routines for 
   additional features      */

    if ((h = make_r_hd(250)) == NULL){
        fprintf (stderr, "ERROR in gray. Insufficent memory to read header\n");
        return 0;
    }

    if (header_pass (datafile, h, 1) == -1){    /* if bad read of header    */
        fprintf (stderr, "ERROR in gray reading header\n");
        free_r_hd(h);
        return 0;
    }

    hdr.numfreq = header_long_p (h, FREQ_KEY);
    hdr.bytespec = header_long_p (h, BYTES_PER_KEY);
    hdr.bytesfreq = header_long_p (h, SAMPLE_SZ_KEY);
    hdr.numspec = header_long_p (h, SPECTRA_KEY);
    hdr.year = header_long_p (h, YEAR_KEY);
    /* v4.2.1 If year is 2-digit (old version), convert to 4-digit */
    hdr.year = (hdr.year < 1900) ? hdr.year + 1900 : hdr.year;
    hdr.topdata = header_tell_p (h, END_KEY);

    free_r_hd(h);
    *header = hdr;

    if (DEBUG) printf ("good leaving read_header\n");

    return 1;
}

/*
 * int check_header
 *
 * checks the header information
 *
 * returns 0 and prints error if header information prevents a good read
 * returns 1 if header information can be dealt with
 *
 */
int check_header (FILE *datafile, hd_strct *header, int numpoints)
{
    char filetype[STR_MAL];
    int rtn, checkstatus, testbytes;
    hd_strct hdr;

    if (DEBUG) printf ("good entering check_header\n");

    /* will write possible changes to hdr and write back to header at end of routine */
    hdr = *header;      


/*  check mandatory keys        */
    rtn = ((check_long ((long) hdr.numfreq, FREQ_KEY)) &&
           (check_long ((long) hdr.bytespec, BYTES_PER_KEY)) &&
           (check_long (hdr.topdata, END_KEY))); 
    
    if (rtn){   /* if info read is good so far          */
/*  if missing optional info, print warning and substiute default information       */

        if (header_string (datafile, FILE_T_KEY, filetype) == 0)
            fprintf (stderr, "WARNING in gray - could not read %s from header\n", 
                FILE_T_KEY);
        else if (strncmp (filetype, "RAW", 3) != 0){
            fprintf (stderr, "WARNING in gray ");
            fprintf (stderr, "read a %s of %s\n", FILE_T_KEY, filetype);
            fprintf (stderr, "should have read RAW\n");
        }

        if (hdr.bytesfreq <= 0){
            fprintf (stderr, "WARNING in gray, assuming header information %s of 1\n", 
                SAMPLE_SZ_KEY);
            hdr.bytesfreq = 1;
        }
        if (hdr.year < 0){
            fprintf (stderr, "WARNING in gray, assuming header information %s of %i\n", 
                YEAR_KEY, DEF_YEAR);
            hdr.year = DEF_YEAR;
        }
    
        if (hdr.numspec < 0){
            hdr.numspec = get_numspec (datafile, hdr.bytespec, hdr.topdata);
            fprintf(stderr,"WARNING in gray, assuming header info %s of %i\n", 
                SPECTRA_KEY, hdr.numspec);
        }

        testbytes = (hdr.numfreq*hdr.bytesfreq) + STMPBYTES;
        if (hdr.bytespec < testbytes){
            fprintf (stderr, "WARNING in gray. Assuming %s of %i\n", BYTES_PER_KEY, 
                testbytes);
            hdr.bytespec = testbytes;
        }

    
        checkstatus = check_size (datafile, hdr.topdata, hdr.numspec, hdr.bytespec);
        switch (checkstatus){
        case 1:
            fprintf (stderr, "WARNING - data file is larger than predicted by header\n");
            fprintf (stderr, "will ignore extra bytes\n");
            break;
        case -1:
            fprintf (stderr, "ERROR - data file is smaller than predicted by header\n");
            rtn = 0;
        }
    }

    if (rtn)
        if (hdr.numfreq < numpoints ){
            fprintf (stderr, "ERROR - trying to read %i data points from a radio file\n",
                numpoints);
            fprintf (stderr, "with %i frequencies\n", hdr.numfreq);
            rtn = 0;
        }

    if (DEBUG) printf ("good leaving check_header - returning %i\n", rtn);

    *header = hdr;                      /* write any changes to header  */

    return rtn;

}

/*
 * int get_numspec
 *
 * estimates a spectra count based on the size of the file and the number of bytes per spectra
 *
 * warning - exits with positioning of datafile undefined
 *
 */
int get_numspec (FILE *datafile, int bytespec, int topdata)
{
    long filesize;
    int rtn;

    fseek (datafile, 0L, SEEK_END);

    filesize = ftell(datafile);
    assert (filesize >= topdata);

    rtn = (filesize - topdata)/bytespec;

    return rtn;
}

/*
 * check_long
 *
 *  checks to make sure that a header element is greater then or equal to zero
 *
 */
int check_long (long chk, char *key)
{
    int rtn;

    assert (key != NULL);
    
    if (chk < 0){
        fprintf (stderr, "ERROR in gray - could not read %s\n", key);
        rtn = 0;
    }
    else
        rtn = 1;
    
    return rtn;

}


/*
 * read_last
 *
 * reads the value of the last timestamp of a radio file
 *
 */
t_stamp read_last (FILE *datafile, hd_strct header)
{
    t_stamp rtn;
    long last_pos;
    
    last_pos = header.topdata + (header.bytespec * (header.numspec - 1));   
    fseek (datafile, last_pos, SEEK_SET);
    rtn = rd_timestamp(datafile);
    
    return rtn;
}

/* 
 * int read_scale
 *
 * reads the scaling information from a datafile 
 * returns 0 on a bad read, 1 otherwise
 *
 */
int read_scale (FILE *datafile, hd_strct header, scl_strct *scale)
{
    scl_strct scl;
    t_stamp first;
    double time_spec;
    long timespan, rough;
    int num_chk;

    if (DEBUG) printf ("good entering read_scale\n");

    if (header.numspec < STMP_CHK)
        num_chk = header.numspec;
    else
        num_chk = STMP_CHK;

    timespan = read_timespan (datafile, header, num_chk);
    if (timespan < 0)
        return 0;

    time_spec = ((double)timespan) / num_chk;   /* calculate average time per spectra*/
    rough = (long)(SPEC_INT * time_spec);       /* calculate rough time per interval*/

    if (rough > DEC_HOUR)
        scl.interval =  rd_intval (hour_intvals, sizeof(hour_intvals)/sizeof(int),
                            DEC_HOUR, rough); 
    else if (rough == DEC_HOUR)
        scl.interval = rough;   
    else {                                      /* rough < DEC_HOUR     */
        scl.interval =  rd_intval (min_intvals, sizeof(min_intvals)/sizeof(int), 
                            DEC_MIN, rough); 
    }
    
        
    fseek (datafile, header.topdata, SEEK_SET); /* read first timestamp */
    first = rd_timestamp (datafile);
    scl.first = roundud (first, scl.interval, UP);/* round up to nearest good interval*/
    if (scl.first > max_stamp)      /* if first stamp would wrap around the new year*/
        scl.first = 0;              /* just have the first stamp be the beginning of the year*/

    /*  make sure at least one timestamp printed - insure that last >= scl.first    */

    (*scale) = scl;

    if (DEBUG) printf ("good leaving read_scale\n");

    return 1;
}

/*
 * long rd_intval
 *
 * reads a timestamp interval to be used for labeling timestamps 
 *
 * passed   -       long intvals[]  array of possible intervals, not neccesarily in
 *                                  deciseconds
 *
 *                  int sz          the number of elements in intvals
 *
 *                  long convert    factor to multiply intvals by to change to decisonds
 *
 *                  long rough      ideal timestamp interval, to adjusted for scaling
 *
 * returns          long            timestamp interval (decisonds) picked from among the
 *                                  possible choices given in intvals[]
 *
 */

long rd_intval (int intvals[], int sz, long convert, long rough)
{
    int i;

    if (rough <= (intvals[0]*convert))
        return (intvals[0]*convert);
    
    for (i=0; i<sz; i++){
        if (i == (sz-1))
            return (intvals[sz-1]*convert);
        else if (((intvals[i]*convert) <= rough) && (rough <= (intvals[i+1]*convert)))
            return (compare (intvals[i]*convert, intvals[i+1]*convert, rough)); 
    }

    assert (1 == 0);        /* this line should never be reached  */
}

/*
 * long read_timespan
 *
 * reads the length of time between the first timestamp and the the i'th timestamp 
 * of a radiofile
 *
 */
long read_timespan (FILE *datafile, hd_strct header, int i)
{
    t_stamp first, chk;
    long chk_pos, rtn;

    assert (datafile != NULL);
    assert (header.numspec >= 1);

    fseek (datafile, header.topdata, SEEK_SET);
    first = rd_timestamp (datafile);

    chk_pos = header.topdata + (header.bytespec * (i - 1));
    fseek (datafile, chk_pos, SEEK_SET);
    chk = rd_timestamp (datafile);
    
    /* timestamp increase monotonically across the end of a year */
    /* don't check for > max_stamp here  or for chk < first */
    if ( chk == BAD_STAMP || first == BAD_STAMP) {
        fprintf (stderr, "ERROR in gray - reading timestamp \n");
        return -1;
    }

    rtn = chk - first;
    return rtn;
}

/*
 * long compare
 *
 * returns one or two, whichever is closer to base 
 *
 */
long compare (long one, long two, long base)
{
    long diff_one = labs (one - base);
    long diff_two = labs (two - base);

    if (diff_one > diff_two)
        return two;

    return one;
}

/*
 * long roundud
 *
 * returns it's argument rounded either rounded up or down to the nearest base
 *
 */
long roundud (long arg, long base, int where)
{
    int mod;
    long rtn;

    assert ((where == UP) || (where == DOWN));
    mod = arg % base;

    if (where == UP)
        rtn = arg + (base - mod);       
    else
        rtn = arg - mod;
    
    return rtn;
}


static int check_leapyear(int year)
{
    if ( (year%4 == 0) && 
        ((year%100 != 0) || ((year%100 == 0) && (year%400) == 0)))
        return 1;
    else
        return 0;
}

