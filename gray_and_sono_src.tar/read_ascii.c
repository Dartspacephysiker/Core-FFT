/* CHECK FOR COMMENT CHAR - DO APPROPRIATE      */
/*
 * read_ascii.c
 * $Header: /usr/local/radio/src/linux/gray/RCS/read_ascii.c,v 1.2 2003/06/02 03:07:56 richard Exp $
 *
 * module responsible for reading data from an ascii data file
 *
 * modification history  30/09/93   Cacioppi modified so that magic timestamps appear in a data file
 *                                  as a replacement to a regular timestamp. Previously, magic timestamps
 *                                  that did appear followed the regular timestamp.  
 */ 

#include "gray.h" 

/*          local prototype         */ 
int get_stamp (FILE *datafile, int magic, char mgc_char, stmp_dta *stamp); 
int get_data (FILE *datafile, int numpoints, int *darr); 
int asc_gets (char *s, int n, FILE *stream);

/* --------------------- functions providing interface ----------------------------- */
/*
 * int read_ascii
 *
 * reads a spectrum from an ascii data file
 *
 * passed   FILE    *datafile   -   the ascii data file to read from
 *          int     numpoints   -   the number of frequencies to return
 *          int     magic       -   boolean - use magic timestamps?
 *          char    mgc_char    -   char which start magic timestamps
 *          int     *darr       -   the array of data points to be filled
 *          stmp_dta *stamp     -   timestamp data to be filled
 *
 * returns  int                 -   GOOD if a good read was executed that did not reach EOF
 *                              -   DTA_EOF if a good read was executed that reached EOF
 *                              -   ERROR if a bad read was executed 
 *
 * exceptions                   -   darr should be large enough to hold numpoints ints
 *
 */
int read_ascii(FILE *datafile,int numpoints,int magic,char mgc_char,int *darr,stmp_dta *stamp)
{
    char bfr;

    if (!get_stamp (datafile, magic, mgc_char, stamp))
        return ERROR;
    

    if (!get_data (datafile, numpoints, darr))
        return ERROR;
    

    bfr = fgetc(datafile);
    if (feof(datafile))
        return DTA_EOF;

    ungetc (bfr, datafile);
    return GOOD;
}

/* ------------------------- functions providing implementation ---------------------------- */
/*
 * int get_stamp
 *
 * reads from a timestamp from datafile into stamp. 
 *
 */
int get_stamp (FILE *datafile, int magic, char mgc_char, stmp_dta *stamp)
{
    int status;
    char str[STR_MAL], bfr;
    stmp_dta stp;           /* dummy - will fill stamp                          */

    assert (datafile != NULL);
    assert (stamp != NULL);

    status = asc_gets (str, sizeof(str), datafile); /* read the normal timestamp*/
    if (status < 0)                                 /* check for EOF*/
        return 0;

    bfr = str[0];
    if (bfr == mgc_char){                       /* if found magic stamp             */
        stp.mgc = 1;                            /* flag the magic timestamp         */
        strcpy (stp.str, &(str[1]));            /* copy over all but the 1st char   */
    }
    else{                                       /* else - normal timestamp          */
        stp.mgc = 0;                            /* flag and copy entire timestamp   */
        strcpy (stp.str, str);
    }

    *stamp = stp;           

    return 1;
}
    
/*
 * int get_data
 *
 */
int get_data (FILE *datafile, int numpoints, int *darr)
{
    int i;
    char bfr[STR_MAL];


    assert (datafile != NULL);
    assert (darr != NULL);

    for (i=0; i<numpoints; i++){
        asc_gets (bfr, sizeof(bfr), datafile);  
        if (feof (datafile))
            return 0;
        darr[i] = atoi (bfr);
    }

    return 1;
}

/*
 * int asc_gets
 *
 * reads data from an ascii file. Ignoring comments, it will continue getting lines until it finds a line not
 * consisting soley of blank space, or until EOF.
 *
 * returns          -       number of chars read (ignoring comments) if good read
 *                  -       -1 if EOF encountered
 *
 */
int asc_gets (char *s, int n, FILE *stream)
{
    char *ptr;
    int offset, length=0;
    int done = 0;

    assert (s != NULL);

    while (!done){
        if (fgets (s, n, stream) == NULL)   /* if EOF or error, return -1       */
            return -1;
        if ((ptr = strchr (s, CMNT_FLAG))   != NULL){   /* if comment found         */
            *ptr = '\n';                            /* end string where comment */
            *(++ptr) = '\0';                        /* was found                */
        }
        length = strlen (s);                        /* get length of s          */
        offset = strspn (s, " \t\n");/* get length of white space prefix of s   */
        if  ((length-offset)>0)                     /* if string is OK          */
            done = 1;                               /* then done with loop      */
    }

    assert (length > 0);
    return length;

}

        
